  <script>
$(document).ready(function(){ 
	$("#edit-details-button").click(function(){
		//$("#customer_details").css("display","none");
		//$("#new_customer_details").load("new_customer.php");
		window.location.replace('?page=new_customer');
	
	});
});

	</script>
    <h2>Pickup Details</h2>   
    